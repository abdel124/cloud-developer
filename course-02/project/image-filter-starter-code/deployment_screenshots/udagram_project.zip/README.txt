Link with token required :

http://udagram-abdel-dev-dev.us-east-1.elasticbeanstalk.com/filteredimage?image_url=https://upload.wikimedia.org/wikipedia/commons/b/bd/Golden_tabby_and_white_kitten_n01.jpg

Token  for postman test= eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFiZGVsQGdtYWlsLmNvbSIsInBhc3N3b3JkX2hhc2giOiIkMmIkMTAkMnRvUW9IZVRKVU1iNkJpTFI1RHpJZWRxeFMvQ3d5Z0lmcUN2Y2tmZGpubjd1Ui5wVnlUMU8iLCJjcmVhdGVkQXQiOiIyMDIyLTEyLTAzVDE5OjQ4OjEwLjk1MVoiLCJ1cGRhdGVkQXQiOiIyMDIyLTEyLTAzVDE5OjQ4OjEwLjk1MVoiLCJpYXQiOjE2NzAwOTY4OTF9.mo1Q3C4E-oPNbk-Bhhxc3oq5CSNGMCXH7G6w9JWJteU


Link with authentification not required :

http://udagram-abdel-dev-dev.us-east-1.elasticbeanstalk.com/authorized/filteredimage?image_url=https://upload.wikimedia.org/wikipedia/commons/b/bd/Golden_tabby_and_white_kitten_n01.jpg


GitHub link :

https://github.com/abdel124/cloud-developer/tree/master/course-02/exercises/udacity-c2-restapi

Note : I have used udacity-c2-restapi respiratory since I need authentication so I moved the files needed from filter image folder to  udacity-c2-restapi like utils.ts